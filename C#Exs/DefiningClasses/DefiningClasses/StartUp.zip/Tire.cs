﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Tire
    {
        /*T03
        private double pressure;
        private int age;

        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }

        public double Pressure
        {
            get
            {
                return pressure;
            }
            set
            {
                pressure = value;
            }
        }

        public Tire(string pressure, string age)
        {
            Pressure = double.Parse(pressure);
            Age = int.Parse(age);
        }
        */
    }
}
